from appium import webdriver
from appium.webdriver.common.touch_action import TouchAction
import time
url = "127.0.0.1:4723/wd/hub"
param ={
  "platformName": "Android",
  "platformVersion": "7.1.2",
  "deviceName": "127.0.0.1:62001",
  "appPackage": "com.sina.weibo",
  "adbExecTimeout": 1000000,
  "appActivity": "com.sina.weibo.SplashActivity",
}
driver = webdriver.Remote(url, param)
action = TouchAction(driver)
action.tap(x=478, y=806).perform()
time.sleep(20)
el1 = driver.find_element_by_id("com.sina.weibo:id/titleBack")
el1.click()
time.sleep(5)
action.tap(x=364, y=1120).perform()
time.sleep(5)
el2 = driver.find_element_by_id("com.sina.weibo:id/et_login_view_uname")
el2.send_keys("1848752660@qq.com")
el3 = driver.find_element_by_id("com.sina.weibo:id/et_login_view_psw")
el3.send_keys("QX#127983")
action.tap(x=95, y=1176).perform()
el4 = driver.find_element_by_id("com.sina.weibo:id/btn_login_view_psw")
el4.click()
time.sleep(100)
