import time
from appium.webdriver.common.touch_action import TouchAction


class LoginOpera:
    def __init__(self, driver):
        self.driver = driver

    # 实际操作
    def login(self, username, password):
        TouchAction(self.driver).tap(x=478, y=806).perform()
        time.sleep(20)
        el1 = self.driver.find_element_by_id("com.sina.weibo:id/titleBack")
        el1.click()
        time.sleep(20)
        TouchAction(self.driver).tap(x=364, y=1120).perform()
        time.sleep(20)
        el2 = self.driver.find_element_by_id("com.sina.weibo:id/et_login_view_uname")
        el2.send_keys(username)
        el3 = self.driver.find_element_by_id("com.sina.weibo:id/et_login_view_psw")
        el3.send_keys(password)
        TouchAction(self.driver).tap(x=95, y=1176).perform()
        el4 = self.driver.find_element_by_id("com.sina.weibo:id/btn_login_view_psw")
        el4.click()
        time.sleep(100)

    def getSuccessResult(self):
        result = "成功"  # 登陆成功后，软件闪退
        return result
