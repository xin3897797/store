from appium import webdriver
from appium.webdriver.common.touch_action import TouchAction
import time


url = "127.0.0.1:4723/wd/hub"

param = {
    "platformName": "Android",
    "platformVersion": "7.1.2",
    "deviceName": "127.0.0.1:62001",
    "appPackage": "com.ss.android.ugc.aweme",
    "adbExecTimeout": 1000000,
    "appActivity": "com.ss.android.ugc.aweme.splash.SplashActivity",
    "noReset": "True"
}
driver = webdriver.Remote(url, param)
time.sleep(50)
action = TouchAction(driver)
action.tap(x=411, y=759).perform()
time.sleep(40)
action.press(x=231, y=931).move_to(x=495, y=245)
time.sleep(2)
action.release().perform()
