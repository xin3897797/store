from unittest import TestCase
from appium import webdriver
from ddt import ddt
from ddt import data
from ddt import unpack
from InitPage import InitPage
from LoginOperation import LoginOpera
import time


@ddt
class TestLogin(TestCase):
    def setUp(self) -> None:
        url = "127.0.0.1:4723/wd/hub"
        param = {
            "platformName": "Android",
            "platformVersion": "7.1.2",
            "deviceName": "127.0.0.1:62001",
            "appPackage": "com.sina.weibo",
            "adbExecTimeout": 1000000,
            "appActivity": "com.sina.weibo.SplashActivity"
        }
        self.driver = webdriver.Remote(url, param)

    def tearDown(self) -> None:
        self.driver.quit()

    @data(*InitPage.login_success_data)
    @unpack
    def testSuccessCase1(self, username, password, expect):
        login = LoginOpera(self.driver)
        login.login(username, password)

        result = login.getSuccessResult()
        time.sleep(1)
        self.assertEqual(expect, result)
