import HTMLTestRunner
import unittest
import os
'''
    模拟器中的软件闪退
'''
tests = unittest.defaultTestLoader.discover(os.getcwd(), pattern="Test*.py")

runner = HTMLTestRunner.HTMLTestRunner(
    title="微博登录测试",
    description="微博登录测试【成功】",
    verbosity=1,
    stream=open(file="微博测试.html", mode="wb+")
)

runner.run(tests)
