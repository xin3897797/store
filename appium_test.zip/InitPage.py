class InitPage:
    login_success_data = [
        ['1848752660@qq.com', 'QX#127983', '成功']
    ]
