import random
import json


def load_json():
    f = open('usr.txt')
    u_dict = json.loads(f.read())  # 将json(字符串)变为字典
    return u_dict


def dump_json(user_dict):
    fw = open('usr.txt', 'w', encoding='utf-8')
    json.dump(user_dict, fw, indent=4)  # dump将字典变为json(字符串)，且写入文件


def add_user(t_dict):
    u_dict = load_json()
    if t_dict['uid'] in u_dict.keys():
        return 2
    else:
        if len(u_dict.keys()) == 100:
            return 3
        else:
            u_dict[t_dict['uid']] = {'name': t_dict['name'], 'password': t_dict['password'],
                                     'address': t_dict['address'], 'deposit': t_dict['deposit'],
                                     'account_bank': t_dict['account_bank']}
            dump_json(u_dict)
            return 1


def save_money(uid, money):
    u_dict = load_json()
    if uid in u_dict.keys():
        u_dict[uid]['deposit'] += money
        dump_json(u_dict)
        return True
    else:
        return False


def withdraw_money(uid, password, money):
    u_dict = load_json()
    if uid in u_dict.keys():
        if password == u_dict[uid]['password']:
            if money <= u_dict[uid]['deposit']:
                u_dict[uid]['deposit'] -= money
                dump_json(u_dict)
                return 0
            else:
                return 3
        else:
            return 2
    else:
        return 1


def transfer(out_id, in_id, out_passwd, money):
    u_dict = load_json()
    if out_id and in_id in u_dict.keys():
        if out_passwd == u_dict[out_id]['password']:
            if money <= u_dict[out_id]['deposit']:
                u_dict[out_id]['deposit'] -= money
                u_dict[in_id]['deposit'] += money
                dump_json(u_dict)
                return 0
            else:
                return 3
        else:
            return 2
    else:
        return 1


def user_info(uid, passwd):
    u_dict = load_json()
    if uid in u_dict.keys():
        if passwd == u_dict[uid]['password']:
            print("{}的信息：".format(uid))
            for k, v in u_dict[uid].items():
                print("{}:{}".format(k, v))
        else:
            print("密码错误")
    else:
        print("该用户不存在")


def screen():
    print("****************************************")
    print("*     中国工商银行                       *")
    print("*     账户管理系统                       *")
    print("*        V1.0                          *")
    print("****************************************")
    print("                                        ")
    print("*1.开户                                 *")
    print("*2.存钱                                 *")
    print("*3.取钱                                 *")
    print("*4.转账                                 *")
    print("*5.查询                                 *")
    print("*6.Bye!                                *")
    print("****************************************")


if __name__ == '__main__':
    user = {'12345678': {'name': 'vlad', 'password': '123456', 'address': '中国-河北-石家庄-99号', 'deposit': '99',
                         'account_bank': '中国工商银行的昌平支行'}}
    screen()
    while True:
        sel = int(input("请输入业务编号："))
        if sel == 1:
            uid = str(random.randint(0, 99999999)).zfill(8)  # zfill(8)的作用就是当字符串不够8位时，在首位填充0
            name = input("请输入用户姓名：")
            password = input("请输入用户密码(6位数字)：")
            address = input("请输入用户地址(国家-省份-街道-门牌号)：")
            deposit = int(input("请输入存款余额："))
            account_bank = input("请输入开户行的名称：")
            temp = {'uid': uid, 'name': name, 'password': password, 'address': address, 'deposit': deposit,
                    'account_bank': account_bank}
            result = add_user(temp)
            if result == 1:
                print("用户添加成功，用户账号为{}".format(uid))
            elif result == 2:
                print("用户账号已存在，请重新操作")
            elif result == 3:
                print("用户库注册已满，无法添加新用户")
        elif sel == 2:
            account = input("请输入用户账号：")
            money = int(input("请输入存入金额："))
            re = save_money(account, money)
            if re:
                print("存入成功")
            else:
                print("没有此用户，请检查用户账号")
        elif sel == 3:
            acc = input("请输入用户账号：")
            passwd = input("请输入用户密码：")
            withdraw = int(input("请输入取钱金额："))
            r = withdraw_money(acc, passwd, withdraw)
            if r == 1:
                print("用户不存在，请检查用户账号")
            elif r == 2:
                print("密码错误，请检查用户密码")
            elif r == 3:
                print("存款不足，请检查取出金额")
            else:
                print("取出成功")
        elif sel == 4:
            out_account = input("请输入转出账号：")
            in_account = input("请输入转入账号：")
            out_passwd = input("请输入转出账号密码：")
            money = int(input("请输入转出金额："))
            res = transfer(out_account, in_account, out_passwd, money)
            if res == 1:
                print("用户不存在，请检查转入和转出账号")
            elif res == 2:
                print("密码不正确，请检查转出账号密码")
            elif res == 3:
                print("存款不足，请检查转出金额")
            else:
                print("转账成功")
        elif sel == 5:
            user_id = input("请输入用户账号：")
            user_passwd = input("请输入用户密码：")
            user_info(user_id, user_passwd)
        elif sel == 6:
            print("退出系统中……")
            break
        else:
            print("输入错误，请检查编号")
