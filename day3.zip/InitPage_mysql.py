"""
    1.数据类：
        只准备数据部分：不参与任何操作。
    任务1：
        将这个框架的数据源集中写到excel表里，使用xlrd读取
        xlrd参数化，mysql的参数化。
"""
import pymysql


class InitPage:
    conn = pymysql.connect(host='localhost', port=3306, database='hkr_test', user='root', passwd='root')
    cursor = conn.cursor()
    sql = "select * from login"
    cursor.execute(sql)
    data = cursor.fetchall()
    login_success_data = [data[0], data[1]]

    login_error_data = [data[2], data[3]]

