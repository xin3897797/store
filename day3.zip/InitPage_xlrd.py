"""
    1.数据类：
        只准备数据部分：不参与任何操作。
    任务1：
        将这个框架的数据源集中写到excel表里，使用xlrd读取
        xlrd参数化，mysql的参数化。
"""
import xlrd


class InitPage:
    wb = xlrd.open_workbook('HKR.xlsx')
    sheet = wb.sheet_by_name('Login')
    login_success_data = [sheet.row_values(1), sheet.row_values(2)]

    login_error_data = [sheet.row_values(3), sheet.row_values(4)]
