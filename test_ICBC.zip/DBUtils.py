import pymysql

host = '127.0.0.1'
port = 3306
db = 'bank'
user = 'root'
passwd = 'root'
charset = 'utf8mb4'


# 增删改
def update(sql, param):
    conn = pymysql.connect(host=host, port=port, db=db, user=user, passwd=passwd, charset=charset)
    cursor = conn.cursor()
    cursor.execute(sql, param)
    conn.commit()
    cursor.close()
    conn.close()


def select(sql, param, mode='all', size=1):
    conn = pymysql.connect(host=host, port=port, db=db, user=user, passwd=passwd, charset=charset)
    cursor = conn.cursor()
    cursor.execute(sql, param)
    data = ""
    if mode == 'all':
        data = cursor.fetchall()
    elif mode == 'one':
        data = cursor.fetchone()
    elif mode == 'many':
        data = cursor.fetchmany(size)
    cursor.close()
    conn.close()
    return data