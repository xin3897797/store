import random
import DBUtils


class Bank:
    uid_list = []
    account_bank = '中国工商银行的昌平支行'
    menu = '''
        ****************************************
        *     中国工商银行                       *"
        *     账户管理系统                       *"
        *        V1.0                          *"
        "***************************************"
        "                                       "
        *1.开户                                 *"
        *2.存钱                                 *"
        *3.取钱                                 *"
        *4.转账                                 *"
        *5.查询                                 *"
        *6.Bye!                                *"
        ****************************************"
    '''
    info = '''
        -------------用户信息--------------------
        账号：{}
        用户名：{}
        密码：******
        国家：{}
        省份：{}
        街道：{}
        门牌号：{}
        余额：{}
        开户行：{}
    '''

    def get_uid(self):
        sql = """select uid from user_info"""
        param = []
        data = DBUtils.select(sql, param)
        for d in data:
            self.uid_list.append(d[0])

    def add_user(self, t_dict):
        self.get_uid()
        if t_dict['uid'] in self.uid_list:
            return 2
        else:
            if len(list(set(self.uid_list))) > 100:
                return 3
            else:
                sql = """insert into user_info(uid,name,password,country,province,street,door,deposit,account_bank)
                    value(%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
                param = [t_dict['uid'], t_dict['name'], t_dict['password'], t_dict['country'], t_dict['province'],
                         t_dict['street'], t_dict['door'], t_dict['deposit'], self.account_bank]
                DBUtils.update(sql, param)
                return 1

    def save_money(self, uid, money):
        self.get_uid()
        sql = """select deposit from user_info where uid=%s"""
        param = [uid]
        data = DBUtils.select(sql, param, 'one')
        if uid in self.uid_list:
            sql1 = """update user_info set deposit=%s where uid=%s"""
            param = [money + data[0], uid]
            DBUtils.update(sql1, param)
            return True
        else:
            return False

    def withdraw_money(self, uid, password, money):
        self.get_uid()
        sql = """select password,deposit from user_info where uid=%s"""
        param = [uid]
        data = DBUtils.select(sql, param, 'one')
        if uid in self.uid_list:
            if password == data[0]:
                if money <= data[1]:
                    sql1 = """update user_info set deposit=%s where uid=%s"""
                    param = [data[1] - money, uid]
                    DBUtils.update(sql1, param)
                    return 0
                else:
                    return 3
            else:
                return 2
        else:
            return 1

    def transfer(self, out_id, in_id, out_passwd, money):
        self.get_uid()
        sql = """select password,deposit from user_info where uid=%s"""
        param = [out_id]
        out_data = DBUtils.select(sql, param, 'one')
        sql1 = """select deposit from user_info where uid=%s"""
        param1 = [in_id]
        in_data = DBUtils.select(sql1, param1, 'one')
        if (out_id and in_id) in self.uid_list:
            if out_passwd == out_data[0]:
                if money <= out_data[1]:
                    sql2 = """update user_info set deposit=%s where uid=%s"""
                    param2 = [out_data[1] - money, out_id]
                    DBUtils.update(sql2, param2)
                    sql3 = """update user_info set deposit=%s where uid=%s"""
                    param3 = [in_data[0] + money, in_id]
                    DBUtils.update(sql3, param3)
                    return 0
                else:
                    return 3
            else:
                return 2
        else:
            return 1

    def user_info(self, uid, passwd):
        self.get_uid()
        sql = """select * from user_info where uid=%s"""
        param = [uid]
        data = DBUtils.select(sql, param, 'one')
        if uid in self.uid_list:
            if passwd == data[2]:
                print(self.info.format(data[0], data[1], data[3], data[4], data[5], data[6], data[7], data[8]))
                return 0
            else:
                print("密码错误")
                return 1
        else:
            print("该用户不存在")
            return 2


if __name__ == '__main__':
    b = Bank()
    print(b.menu)
    while True:
        sel = int(input("请输入业务编号："))
        if sel == 1:
            uid = str(random.randint(0, 99999999)).zfill(8)  # zfill(8)的作用就是当字符串不够8位时，在首位填充0
            name = input("请输入用户姓名：")
            password = input("请输入用户密码(6位数字)：")
            print("请输入用户地址：")
            country = input("\t\t请输入国家：")
            province = input("\t\t请输入省份：")
            street = input("\t\t请输入街道：")
            door = input("\t\t请输入门牌号：")
            temp = {'uid': uid, 'name': name, 'password': password, 'country': country, 'province': province,
                    'street': street, 'door': door, 'deposit': 0}
            result = b.add_user(temp)
            if result == 1:
                print("用户添加成功，用户信息如下")
                print(b.info.format(uid, name, country, province, street, door, 0, b.account_bank))
            elif result == 2:
                print("用户账号已存在，请重新操作")
            elif result == 3:
                print("用户库注册已满，无法添加新用户")
        elif sel == 2:
            account = input("请输入用户账号：")
            money = float(input("请输入存入金额："))
            re = b.save_money(account, money)
            if re:
                print("存入成功")
            else:
                print("没有此用户，请检查用户账号")
        elif sel == 3:
            acc = input("请输入用户账号：")
            passwd = input("请输入用户密码：")
            withdraw = float(input("请输入取钱金额："))
            r = b.withdraw_money(acc, passwd, withdraw)
            if r == 1:
                print("用户不存在，请检查用户账号")
            elif r == 2:
                print("密码错误，请检查用户密码")
            elif r == 3:
                print("存款不足，请检查取出金额")
            else:
                print("取出成功")
        elif sel == 4:
            out_account = input("请输入转出账号：")
            in_account = input("请输入转入账号：")
            out_passwd = input("请输入转出账号密码：")
            money = float(input("请输入转出金额："))
            res = b.transfer(out_account, in_account, out_passwd, money)
            if res == 1:
                print("用户不存在，请检查转入和转出账号")
            elif res == 2:
                print("密码不正确，请检查转出账号密码")
            elif res == 3:
                print("存款不足，请检查转出金额")
            else:
                print("转账成功")
        elif sel == 5:
            user_id = input("请输入用户账号：")
            user_passwd = input("请输入用户密码：")
            b.user_info(user_id, user_passwd)
        elif sel == 6:
            print("退出系统中……")
            break
        else:
            print("输入错误，请检查编号")
