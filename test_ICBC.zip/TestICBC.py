from unittest import TestCase
from ICBC import Bank
from ddt import ddt
from ddt import data
from ddt import unpack
import xlrd

da = []
wb = xlrd.open_workbook(filename='ICBC.xlsx')
sheet = wb.sheet_by_index(0)
for row in range(6):
    row_value = sheet.row_values(row)
    da.append([{"uid": row_value[0], "name": row_value[1], "password": row_value[2], "country": row_value[3],
                "province": row_value[4], "street": row_value[5], "door": row_value[6], "deposit": row_value[7]},
               row_value[8]])
for row in range(7, 9):
    row_value = sheet.row_values(row)
    da.append([row_value[0], row_value[1], row_value[2]])
for row in range(10, 14):
    row_value = sheet.row_values(row)
    da.append([row_value[0], row_value[1], row_value[2], row_value[3]])
for row in range(15, 21):
    row_value = sheet.row_values(row)
    da.append([row_value[0], row_value[1], row_value[2], row_value[3], row_value[4]])


@ddt
class TestICBC(TestCase):
    @data(*da[1:6])
    @unpack
    def testAddUser(self, a, b):
        bank = Bank()
        s = bank.add_user(a)
        self.assertEqual(s, b)

    @data(*da[6:8])
    @unpack
    def testSaveMoney(self, a, b, c):
        bank = Bank()
        s = bank.save_money(a, b)
        self.assertEqual(s, c)

    @data(*da[8:12])
    @unpack
    def testWithdrawMoney(self, a, b, c, d):
        bank = Bank()
        s = bank.withdraw_money(a, b, c)
        self.assertEqual(s, d)

    @data(*da[12:18])
    @unpack
    def testTransfer(self, a, b, c, d, e):
        bank = Bank()
        s = bank.transfer(a, b, c, d)
        self.assertEqual(s, e)
