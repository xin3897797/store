# -*- coding: utf-8 -*-
'''
    HTMLTestRunner：运行器，可以运行和生成测试报告
'''
import HTMLTestRunner
import unittest
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.header import Header
import smtplib
import os

# 1.加载16条用例
tests = unittest.defaultTestLoader.discover(os.getcwd(), pattern="Test*.py")

# 2.创建运行器
runner = HTMLTestRunner.HTMLTestRunner(
    title="中国工商银行系统测试报告",
    verbosity=1,
    stream=open(file="银行系统报告.html", mode="w+", encoding="utf-8")
)

# 3.让运行器运行4条用例
runner.run(tests)

# 4.代码 163 发送邮件，将报告添加为附件，发送给我13552648187@163.com
f = open("银行系统报告.html", 'rb',).read()
# f.close()
att = MIMEText(f, 'base64', 'utf-8')
att['content-type'] = 'application/octet-stream'
att['content-disposition'] = "attachment; filename =testing_bank_result.html"
msg = MIMEText('你好，附件是本次的测试报告，请查阅!发件人：齐馨', 'plain', 'utf-8')

msg_all = MIMEMultipart('related')
msg_all['Subject'] = Header('自动化测试报告', "utf-8")

print('添加附件')
msg_all.attach(att)
print('添加成功')
msg_all.attach(msg)

smtp = smtplib.SMTP()
smtp.connect('smtp.qq.com', 25)
smtp.login('1848752660@qq.com', 'yhpwiczexhjbfaig')
smtp.sendmail('1848752660@qq.com', '13552648187@163.com', msg_all.as_string())
smtp.quit()
print('email has send out!')
