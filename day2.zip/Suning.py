from selenium import webdriver
import time

driver = webdriver.Chrome()
driver.get("https://www.suning.com/")
driver.maximize_window()

driver.find_element_by_xpath('//*[@id="searchKeywords"]').send_keys("电脑")
driver.find_element_by_xpath('//*[@id="searchSubmit"]').click()
time.sleep(2)
driver.find_element_by_xpath('//*[@id="ssdsn_search_pro_baoguang-1-0-1_1_01:0070640451_11930949107"]').click()
windows = driver.window_handles
driver.switch_to.window(windows[-1])
driver.find_element_by_xpath('//*[@id="addCart"]').click()
time.sleep(3)
driver.find_element_by_xpath('/html/body/div[38]/div/div[2]/div/div[1]/a').click()
driver.quit()