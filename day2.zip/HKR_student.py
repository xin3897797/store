from selenium import webdriver
import time
driver = webdriver.Chrome()
driver.get("http://localhost:8080/HKR")
driver.maximize_window()
# 学生登录
driver.find_element_by_xpath('//*[@id="loginname"]').send_keys("aaaaa")
driver.find_element_by_xpath('//*[@id="password"]').send_keys("aaaaa")
driver.find_element_by_xpath('//*[@id="submit"]').click()
# 修改图像
driver.find_element_by_xpath('//*[@id="img"]').click()
time.sleep(2)
driver.find_element_by_xpath('//*[@id="ul_pic"]/li[2]/img').click()
# 上传图像
driver.find_element_by_xpath('//*[@id="file1"]').send_keys(r"D:\Lenovo\Pictures\风景图\1.jpg")
driver.find_element_by_xpath('//*[@id="pic_btn"]').click()

# 提交今日评价
time.sleep(2)
driver.find_element_by_xpath('//*[@id="tt"]/div[1]/div[3]/ul/li[1]/a').click()
driver.refresh()
time.sleep(2)
driver.find_element_by_xpath('//*[@id="form_table"]/tbody/tr[2]/td[2]/select').send_keys("9")
driver.find_element_by_xpath('//*[@id="tea_td"]/select').send_keys("贾生")
driver.find_element_by_xpath('//*[@id="form_table"]/tbody/tr[5]/td[3]/div/label[2]/div').click()
driver.find_element_by_xpath('//*[@id="form_table"]/tbody/tr[6]/td[2]/div/label[2]/div').click()
driver.find_element_by_xpath('//*[@id="form_table"]/tbody/tr[7]/td[3]/div/label[3]/div').click()
driver.find_element_by_xpath('//*[@id="form_table"]/tbody/tr[8]/td[2]/div/label[2]/div').click()
driver.find_element_by_xpath('//*[@id="form_table"]/tbody/tr[9]/td[2]/div/label[2]/div').click()
driver.find_element_by_xpath('//*[@id="form_table"]/tbody/tr[10]/td[3]/div/label[2]/div').click()
driver.find_element_by_xpath('//*[@id="form_table"]/tbody/tr[11]/td[2]/div/label[2]/div').click()
driver.find_element_by_xpath('//*[@id="form_table"]/tbody/tr[12]/td[2]/div/label[2]/div').click()
driver.find_element_by_xpath('//*[@id="textarea"]').send_keys("无")
driver.find_element_by_xpath('//*[@id="subtn"]').click()
time.sleep(2)
driver.find_element_by_xpath('/html/body/div[7]/div[3]/a').click()

# 修改个人信息
time.sleep(2)
driver.find_element_by_xpath('//*[@id="_easyui_tree_8"]/span[4]/a').click()
time.sleep(2)
driver.find_element_by_xpath('//*[@id="info"]/table/tbody/tr[1]/td[2]/input').clear()
driver.find_element_by_xpath('//*[@id="info"]/table/tbody/tr[1]/td[2]/input').send_keys("aaaaa")
driver.find_element_by_xpath('//*[@id="info"]/table/tbody/tr[3]/td[2]/input').clear()
driver.find_element_by_xpath('//*[@id="info"]/table/tbody/tr[3]/td[2]/input').send_keys("aaaaa")
driver.find_element_by_xpath('//*[@id="_easyui_textbox_input1"]').send_keys("50")
driver.find_element_by_xpath('//*[@id="info"]/table/tbody/tr[5]/td[2]/select').send_keys("女")
driver.find_element_by_xpath('//*[@id="info"]/table/tbody/tr[6]/td[2]/input').clear()
driver.find_element_by_xpath('//*[@id="info"]/table/tbody/tr[6]/td[2]/input').send_keys("2")
driver.find_element_by_xpath('//*[@id="info"]/table/tbody/tr[8]/td[2]/input').clear()
driver.find_element_by_xpath('//*[@id="info"]/table/tbody/tr[8]/td[2]/input').send_keys("484669732@qq.com")
driver.find_element_by_xpath('//*[@id="info"]/table/tbody/tr[9]/td[2]/textarea').clear()
driver.find_element_by_xpath('//*[@id="info"]/table/tbody/tr[9]/td[2]/textarea').send_keys("wu")
time.sleep(2)
driver.find_element_by_xpath('//*[@id="btn_modify"]').click()

# 查询所有好友
driver.find_element_by_xpath('//*[@id="_easyui_tree_10"]/span[4]/a').click()

# 退出
time.sleep(2)
driver.find_element_by_xpath('//*[@id="top"]/div/a[2]').click()
time.sleep(2)
driver.quit()