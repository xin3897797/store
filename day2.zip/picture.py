import re
import base64
import cv2


def download(url, name):
    """
    将base64编码的图片下载
    """
    result = re.search("data:image/(?P<ext>.*?);base64,(?P<data>.*)", url, re.DOTALL)
    if result:
        ext = result.groupdict().get("ext")
        data = result.groupdict().get("data")
    else:
        raise Exception("Do not parse!")

    img = base64.urlsafe_b64decode(data)

    filename = "{}.{}".format(name, ext)
    with open(filename, "wb") as f:
        f.write(img)


def identify_gap(bg, tp):
    '''
    bg: 背景图片
    tp: 缺口图片
    out:输出图片
    '''
    # 读取背景图片和缺口图片
    bg_img = cv2.imread(bg)  # 背景图片
    tp_img = cv2.imread(tp)  # 缺口图片
    # 改变尺寸
    bg_img = cv2.resize(bg_img, dsize=(278, 108), fx=1, fy=1, interpolation=cv2.INTER_LINEAR)
    tp_img = cv2.resize(tp_img, dsize=(39, 39), fx=1, fy=1, interpolation=cv2.INTER_LINEAR)
    # 识别图片边缘
    bg_edge = cv2.Canny(bg_img, 100, 200)
    tp_edge = cv2.Canny(tp_img, 100, 200)

    # 转换图片格式
    bg_pic = cv2.cvtColor(bg_edge, cv2.COLOR_GRAY2RGB)
    tp_pic = cv2.cvtColor(tp_edge, cv2.COLOR_GRAY2RGB)

    # 缺口匹配
    res = cv2.matchTemplate(bg_pic, tp_pic, cv2.TM_CCOEFF_NORMED)
    min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)  # 寻找最优匹配

    # 返回缺口的X坐标
    return max_loc
