from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
import time
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.keys import Keys

driver = webdriver.Chrome()
action = ActionChains(driver)
driver.get("http://localhost:8080/HKR")
driver.maximize_window()
# 教师登录
driver.find_element_by_xpath('/html/body/div/div/div[1]/div[2]/a[2]').click()
driver.find_element_by_xpath('//*[@id="loginname"]').send_keys("jason")
driver.find_element_by_xpath('//*[@id="password"]').send_keys("admin")
driver.find_element_by_xpath('//*[@id="submit"]').click()
# 查询
driver.find_element_by_xpath('//*[@id="_easyui_tree_11"]/span[4]/a').click()
time.sleep(2)
driver.find_element_by_xpath('//*[@id="sear_teaname"]').send_keys("贾生")
driver.find_element_by_xpath('//*[@id="search_user"]').click()
# 重置密码
driver.find_element_by_xpath('//*[@id="datagrid-row-r1-2-0"]/td[9]/div/a').click()
time.sleep(2)
driver.switch_to.alert.accept()
# # 姓名和电话号码查询
# driver.find_element_by_xpath('//*[@id="_easyui_tree_12"]/span[4]/a').click()
# time.sleep(2)
# driver.find_element_by_xpath('//*[@id="J-stu"]').send_keys("jason")
# driver.find_element_by_xpath('//*[@id="J-phone"]').send_keys("13548554150")
# driver.find_element_by_xpath('//*[@id="stu_panel"]/div/div/div[1]/table/tbody/tr/td[4]/a').click()
# # 设置毕业状态
# time.sleep(2)
# driver.find_element_by_xpath('//*[@id="datagrid-row-r1-2-0"]/td[11]/div/a').click()
# time.sleep(2)
# driver.find_element_by_xpath('/html/body/div[8]/div[3]/a/span/span').click()

# # 添加课程
# driver.find_element_by_xpath('//*[@id="_easyui_tree_13"]/span[4]/a').click()
# time.sleep(2)
# driver.find_element_by_xpath('//*[@id="course_panel"]/div/div/div[1]/table/tbody/tr/td/a').click()
# time.sleep(2)
# driver.find_element_by_xpath('//*[@id="course_form_add"]/table/tbody/tr[1]/td[2]/input').send_keys("数据结构4")
# driver.find_element_by_xpath('//*[@id="course_form_add"]/table/tbody/tr[2]/td[2]/textarea').send_keys("算法基础，好好学")
# driver.find_element_by_xpath('/html/body/div[7]/div[3]/a[1]').click()
# time.sleep(2)
# driver.find_element_by_xpath('/html/body/div[10]/div[3]/a').click()
# # 取消添加课程
# time.sleep(2)
# driver.find_element_by_xpath('//*[@id="course_panel"]/div/div/div[1]/table/tbody/tr/td/a').click()
# time.sleep(2)
# driver.find_element_by_xpath('/html/body/div[7]/div[3]/a[2]').click()

# # 查询评价
# driver.find_element_by_xpath('//*[@id="_easyui_tree_15"]/span[4]/a').click()
# time.sleep(2)
# # 删除readonly
# js = 'document.getElementById("J-xl").removeAttribute("readonly")'
# driver.execute_script(js)

# driver.find_element_by_xpath('//*[@id="J-xl"]').clear()
# driver.find_element_by_xpath('//*[@id="J-xl"]').send_keys("2021-10-11")
# driver.find_element_by_xpath('//*[@id="eva"]/div/div/div[1]/table/tbody/tr/td[2]/a').click()
# try:
#     time.sleep(3)
#     driver.find_element_by_xpath('/html/body/div[7]/div[3]/a').click()
# except NoSuchElementException:
#     pass
#
# # 导出当前评价
# driver.find_element_by_xpath('//*[@id="eva"]/div/div/div[1]/table/tbody/tr/td[4]/a').click()
#
# # 评价报表
# driver.find_element_by_xpath('//*[@id="_easyui_tree_16"]/span[4]/a').click()
#
# # 日期查询日志
# driver.find_element_by_xpath('//*[@id="_easyui_tree_18"]/span[4]/a').click()
# js = 'document.getElementById("J-history").removeAttribute("readonly")'
# driver.execute_script(js)
# driver.find_element_by_xpath('//*[@id="J-history"]').send_keys("2021-10-11")
# driver.find_element_by_xpath('//*[@id="history"]/div/div/div[1]/table/tbody/tr/td[2]/a').click()
#
# # 导出当前日志
# driver.find_element_by_xpath('//*[@id="history"]/div/div/div[1]/table/tbody/tr/td[4]/a').click()
# # 显示第xx页数据
# driver.find_element_by_xpath('//*[@id="history"]/div/div/div[3]/table/tbody/tr/td[7]/input').clear()
# driver.find_element_by_xpath('//*[@id="history"]/div/div/div[3]/table/tbody/tr/td[7]/input').send_keys("3")
# # 回车
# time.sleep(5)
# driver.find_element_by_xpath('//*[@id="history"]/div/div/div[3]/table/tbody/tr/td[7]/input').send_keys(Keys.ENTER)
