from selenium import webdriver
import time
from selenium.webdriver.common.action_chains import ActionChains
driver = webdriver.Chrome()
driver.get("https://www.taobao.com/")
driver.maximize_window()
driver.find_element_by_xpath('//*[@id="q"]').send_keys("电脑")
driver.find_element_by_xpath('//*[@class="btn-search tb-bg" and @type="submit"]').click()
time.sleep(2)
driver.find_element_by_xpath('//*[@id="login-form"]/div[5]/a[2]').click()  # 支付宝扫码登录
time.sleep(40)  # 等待扫码登录
driver.find_element_by_xpath('//*[@id="J_Itemlist_PLink_641716026027"]').click()
windows = driver.window_handles
driver.switch_to.window(windows[-1])
# driver.find_element_by_xpath('//*[@id="J_LinkBasket"]').click()  # 被拦截，且验证码手动也不行
time.sleep(5)
slider = driver.find_element_by_xpath('//*[@id="nc_1_n1z"]')
action = ActionChains(driver)
action.click_and_hold(slider).move_by_offset(300, 0).perform()
action.release().perform()
driver.quit()
