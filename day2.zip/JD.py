from selenium import webdriver
import picture
import time
from selenium.webdriver.common.action_chains import ActionChains
"""
    滑块验证中，即使滑块对上也会验证失败，可能是因为网站反自动化的结果
    先将滑块验证改为手动验证
"""
driver = webdriver.Chrome()
driver.get(r"https://www.jd.com/")

driver.execute_script('Object.defineProperties(navigator,{webdriver:{get:()=>false}})')
driver.maximize_window()
# 搜索 提交
driver.find_element_by_xpath('//*[@id="key"]').send_keys("电脑")
driver.find_element_by_xpath('//*[@clstag="h|keycount|head|search_a"]').click()
time.sleep(2)
# 点击商品
driver.find_element_by_xpath('//*[@id="J_goodsList"]/ul/li[2]/div/div[3]/a').click()
# 切换窗口
windows = driver.window_handles
driver.switch_to.window(windows[-1])
# 点击购物车
driver.find_element_by_xpath('//*[@id="InitCartUrl"]').click()
# 点击账号登录
time.sleep(2)
driver.find_element_by_xpath('//*[@id="content"]/div[2]/div[1]/div/div[3]/a').click()
# 输入账号密码 登录
driver.find_element_by_xpath('//*[@id="loginname"]').send_keys("17733605784")
driver.find_element_by_xpath('//*[@id="nloginpwd"]').send_keys("QX_142622")
driver.find_element_by_xpath('//*[@id="loginsubmit"]').click()
# 滑块验证
action = ActionChains(driver)
# 获取两张图片
url1 = driver.find_element_by_xpath(
    '//*[@id="JDJRV-wrap-loginsubmit"]/div/div/div/div[1]/div[2]/div[1]/img').get_attribute('src')
picture.download(url1, 'background')
url2 = driver.find_element_by_xpath(
    '//*[@id="JDJRV-wrap-loginsubmit"]/div/div/div/div[1]/div[2]/div[2]/img').get_attribute('src')
picture.download(url2, 'slider')
# 获取距离
d = picture.identify_gap('background.png', 'slider.png')
print(d)
slider = driver.find_element_by_xpath('//*[@id="JDJRV-wrap-loginsubmit"]/div/div/div/div[2]/div[1]/div[1]')
action.click_and_hold(slider).move_by_offset(d[0] - 1, 0)
action.release().perform()
time.sleep(10)  # 留给手动验证的时间
driver.quit()