class Calc:
    def add(self, a, b):
        return a + b

    def minus(self, a, b):
        return a - b

    def multi(self, a, b):
        return a * b

    def division(self, a, b):
        return a / b
