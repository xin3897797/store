'''
    unittest：单元测试框架。
    1.子类继承TestCase
    2.写测试用例,testXxx
    3.运行

'''
from unittest import TestCase
from Calc import Calc
from ddt import ddt
from ddt import data
from ddt import unpack
import xlrd

da = []
wb = xlrd.open_workbook(filename="calc.xlsx")
sheet = wb.sheet_by_index(0)
for row in range(sheet.nrows):
    da.append(sheet.row_values(row))


@ddt
class TestAdd(TestCase):
    @data(*da[1:5])
    @unpack
    def testAdd(self, a, b, c):
        calc = Calc()
        s = calc.add(a, b)
        # 判断，断言
        self.assertEqual(c, s)


@ddt
class TestMinus(TestCase):
    @data(*da[6:10])
    @unpack
    def testMinus(self, a, b, c):
        calc = Calc()
        m = calc.minus(a, b)

        # 判断，断言
        self.assertEqual(c, m)


@ddt
class TestMulti(TestCase):
    @data(*da[11:15])
    @unpack
    def testMulti(self, a, b, c):
        calc = Calc()
        s = calc.multi(a, b)

        # 判断，断言
        self.assertEqual(c, s)


@ddt
class TestDivision(TestCase):
    @data(*da[16:20])
    @unpack
    def testDivision(self, a, b, c):
        calc = Calc()
        d = calc.division(a, b)

        # 判断，断言
        self.assertEqual(c, d)
