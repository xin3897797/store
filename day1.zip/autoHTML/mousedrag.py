from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
import time
driver = webdriver.Chrome()
driver.get(r"F:\codework\autoweb\day1\html\mousedrag.html")
f = driver.find_element_by_xpath('//*[@class="iconfont icon-double-right"]')
action = ActionChains(driver)
action.click_and_hold(f)
action.move_by_offset(284, 0)
action.release()
action.perform()
time.sleep(2)
driver.quit()

