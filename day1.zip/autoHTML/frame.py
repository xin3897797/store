from selenium import webdriver
import time
driver = webdriver.Chrome()
driver.get(r"F:\codework\autoweb\day1\html\frame.html")
driver.find_element_by_xpath('//*[@id="input1"]').send_keys("hello")
time.sleep(2)
driver.quit()
