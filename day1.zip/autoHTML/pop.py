from selenium import webdriver
import time
driver = webdriver.Chrome()
driver.get(r"F:\codework\autoweb\day1\html\pop.html")
driver.find_element_by_xpath('//*[@id="goo"]').click()
time.sleep(2)
driver.quit()
