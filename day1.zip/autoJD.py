from selenium import webdriver
import time

driver = webdriver.Chrome()
driver.get(r"https://www.jd.com/")
driver.find_element_by_xpath('//*[@id="key"]').send_keys("电脑")
driver.find_element_by_xpath('//*[@clstag="h|keycount|head|search_a"]').click()
windows = driver.window_handles  # 获取当前的所有窗口
driver.switch_to.window(windows[0])  # 切换到最新打开的窗口
driver.find_element_by_xpath('//*[@id="J_goodsList"]/ul/li[2]/div/div[3]/a').click()
time.sleep(2)
driver.quit()
