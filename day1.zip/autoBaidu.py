from selenium import webdriver
import time
driver = webdriver.Chrome()
driver.get(r"https://www.baidu.com/")
driver.find_element_by_xpath('//*[@id="kw"]').send_keys("hello")
driver.find_element_by_xpath('//*[@id="su"]').click()
time.sleep(2)
driver.quit()