'''
    unittest：单元测试框架。
    1.子类继承TestCase
    2.写测试用例,testXxx
    3.运行

'''
from unittest import TestCase
from Calc import Calc


class TestAdd(TestCase):

    def testAdd1(self):
        num1 = 10
        num2 = 10
        sum = 20

        calc = Calc()
        s = calc.add(num1, num2)

        # 判断，断言
        self.assertEqual(sum, s)

    def testAdd2(self):
        num1 = -10
        num2 = -10
        sum = -20

        calc = Calc()
        s = calc.add(num1, num2)

        # 判断，断言
        self.assertEqual(sum, s)

    def testAdd3(self):
        num1 = -10
        num2 = 10
        sum = 0

        calc = Calc()
        s = calc.add(num1, num2)

        # 判断，断言
        self.assertEqual(sum, s)

    def testAdd4(self):
        num1 = 100000000000000000000000000000000000000000000000000000
        num2 = 10
        sum = 100000000000000000000000000000000000000000000000000010

        calc = Calc()
        s = calc.add(num1, num2)

        # 判断，断言
        self.assertEqual(sum, s)


class TestMinus(TestCase):
    def testMinus1(self):
        num1 = 10
        num2 = 10
        minus = 0

        calc = Calc()
        m = calc.minus(num1, num2)

        # 判断，断言
        self.assertEqual(minus, m)

    def testMinus2(self):
        num1 = -10
        num2 = -10
        minus = 0

        calc = Calc()
        m = calc.minus(num1, num2)

        # 判断，断言
        self.assertEqual(minus, m)

    def testMinus3(self):
        num1 = -10
        num2 = 10
        minus = -20

        calc = Calc()
        m = calc.minus(num1, num2)

        # 判断，断言
        self.assertEqual(minus, m)

    def testMinus4(self):
        num1 = 100000000000000000000000000000000000000000000000000010
        num2 = 10
        minus = 100000000000000000000000000000000000000000000000000000

        calc = Calc()
        m = calc.minus(num1, num2)

        # 判断，断言
        self.assertEqual(minus, m)


class TestMulti(TestCase):
    def testMulti1(self):
        num1 = 10
        num2 = 10
        multi = 100

        calc = Calc()
        s = calc.multi(num1, num2)

        # 判断，断言
        self.assertEqual(multi, s)

    def testMulti2(self):
        num1 = -10
        num2 = -10
        multi = 100

        calc = Calc()
        s = calc.multi(num1, num2)

        # 判断，断言
        self.assertEqual(multi, s)

    def testMulti3(self):
        num1 = -10
        num2 = 10
        multi = -100

        calc = Calc()
        s = calc.multi(num1, num2)

        # 判断，断言
        self.assertEqual(multi, s)

    def testMulti4(self):
        num1 = 100000000000000000000000000000000000000000000000000000
        num2 = 10
        multi = 1000000000000000000000000000000000000000000000000000000

        calc = Calc()
        s = calc.multi(num1, num2)

        # 判断，断言
        self.assertEqual(multi, s)


class TestDivision(TestCase):
    def testDivision1(self):
        num1 = 10
        num2 = 10
        div = 1

        calc = Calc()
        d = calc.division(num1, num2)

        # 判断，断言
        self.assertEqual(div, d)

    def testDivision2(self):
        num1 = -10
        num2 = -10
        div = 1

        calc = Calc()
        d = calc.division(num1, num2)

        # 判断，断言
        self.assertEqual(div, d)

    def testDivision3(self):
        num1 = -10
        num2 = 10
        div = -1

        calc = Calc()
        d = calc.division(num1, num2)

        # 判断，断言
        self.assertEqual(div, d)

    def testDivision4(self):
        num1 = 100000000000000000000000000000000000000000000000000000
        num2 = 10
        div = 10000000000000000000000000000000000000000000000000000

        calc = Calc()
        d = calc.division(num1, num2)

        # 判断，断言
        self.assertEqual(div, d)
